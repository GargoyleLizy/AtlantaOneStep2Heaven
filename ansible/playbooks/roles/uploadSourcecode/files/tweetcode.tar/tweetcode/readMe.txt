1. emotionDict 统计了常用Emotion表情对应的unicode编码和对于的形容词
2. sentimentV2.py 分析推文，返回[-1,1]之间的值，-1 表示negative 1 表示 positive
3. sentimentV2 调用 pattern.en中的 sentiment方法，并加入Unicode 表情的比对
4. 需要安装 pattern library for python,  安装方法 'pip install pattern'  reference: http://www.clips.ua.ac.be/pattern