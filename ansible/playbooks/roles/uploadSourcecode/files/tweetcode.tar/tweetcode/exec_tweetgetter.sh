#!/bin/bash

python tweetgetter.py 0 0
