
from couchdb.design import ViewDefinition
from pattern.en import sentiment
from TweetStore import TweetStore
from time import sleep
import json
import inspect
import couchdb
import sys

USERNAME = ''
PASSWORD = ''
TARGET_URL = '127.0.0.1'
SOURCE_JSON_FILE = ''
SOURCE_JSON_FILE_LEN = sum(1 for line in open(SOURCE_JSON_FILE))
TARGET_DB = 'test_db'

if (USERNAME == '') or (PASSWORD == ''):
    COUCH_SERVER = 'http://'+TARGET_URL+':5984/'
else:
    COUCH_SERVER = 'http://'+USERNAME+':'+PASSWORD+'@'+TARGET_URL+':5984/'


emotionDict = {}

# load the dictionary
with open('emotionDict', 'r') as f:
	emotionDict = json.loads(f.readline())
	print emotionDict


# calculate the sentiment score,return a score
def getScore(tweets, emotionDict):

	# get the basic Score for text of tweets
	basicScore = sentiment(tweets)[0]

	# store the
	emotionScore = 0
	emotionNumber = 0

	# retrivel the Dictionary find the corresponding adjective
	for key in emotionDict.keys():
		if key in tweets:
			emotionScore = emotionScore + sentiment(emotionDict[key])[0]
			emotionNumber += 1

	if emotionNumber == 0:
		return basicScore
	else:
		finalScore = (basicScore + emotionScore / emotionNumber) / 2
		return finalScore


##################################################
# ================================ I dont know facking why. later.
for name, obj in inspect.getmembers(couchdb):
    if inspect.isclass(obj):
        print obj
# ===================================

server = couchdb.Server(COUCH_SERVER)
db = server[TARGET_DB]
DB_LEN = len(db)
print SOURCE_JSON_FILE_LEN
cnt = 0
percentage = 0

storage = TweetStore(TARGET_DB, COUCH_SERVER)

with open(SOURCE_JSON_FILE, "r") as f:
    for line in f:
        doc = json.loads(line)
        if 'text' in doc:
            #print doc['text']
            doc['sentiment'] = getScore(doc['text'],emotionDict) # plus code here#
            try:
                storage.save_tweet(doc)
            except Exception:
                print "Duplication file_to_db.py"
                pass

        cnt += 1
        #print cnt
        #print int(round((float(cnt)/float(DB_LEN))*100))

        if int(round((float(cnt)/float(SOURCE_JSON_FILE_LEN))*100)) >= percentage:
    	   #print percentage
    	   percentage = int(round((float(cnt)/float(SOURCE_JSON_FILE_LEN))*100))
    	   sys.stdout.write('\r')
    	   # the exact output you're looking for:
    	   sys.stdout.write("[%-20s] %d%%" % ('='*percentage, percentage))
    	   sys.stdout.flush()